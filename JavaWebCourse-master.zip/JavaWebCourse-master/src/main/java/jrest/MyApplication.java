package jrest;

import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("jrest")
public class MyApplication extends ResourceConfig{
    public MyApplication(){
        
    }
}
